#include <iostream>
#include <cstdlib>
#include <ctime>
#include <stdio.h>
#include <time.h>
#include <Windows.h>

using namespace std;

// Function Prototypes
int slotMachine(int playersChips, int playerAmountBet); // Function to hold the code for the slots machine
inline int randomNumber(); // Generates random number from 2 - 7
int playerChipWinnings(const int slotIndex[], int chipAmount, int betAmount); // Calculates how many chips the player has won
void drawNumbers(int slotsNumber); // Draws the numbers for slots
void wait(int seconds); // Function to make the program wait for (x) amount of miliseconds 
int exitGame(); // Exits the game 
void returnMainMenu(); // returns to main menu
void setTextColour(int colourOfText); // sets the colour of the text
void creditsText(); // draws the text in the credits


// Global variables to keep track of players stats
int amountWon = 0;
int amountLost = 0;

int main()
{
	// Variables I will use in my program
	string mainMenu = "0"; // make character, check for characters instead
	int playersChips = 2000;
	int playerAmountBet = 0;
	int newPlayerChips = 0;

	// Variables for the player's stats
	int amountBet = 0;
	int timesPlayed = 0;
	int timesReset = 0;


	// Seeding the random number
	srand((unsigned int)time(0));

	// Main menu for the slot machine

	while (mainMenu == "0")
	{
		system("cls");
		setTextColour(11);
		cout << "=======================================================================================================================" << endl;
		cout << "          .----------------.  .----------------.  .----------------.  .----------------.  .----------------.            " << endl;
		cout << "         | .--------------. || .--------------. || .--------------. || .--------------. || .--------------. |           " << endl;
		cout << "         | |    _______   | || |   _____      | || |     ____     | || |  _________   | || |    _______   | |           " << endl;
		cout << "         | |   /  ___  |  | || |  |_   _|     | || |   .'    `.   | || | |  _   _  |  | || |   /  ___  |  | |           " << endl;
		cout << "         | |  |  (__ \\_|  | || |    | |       | || |  /  .--.  \\  | || | |_/ | | \\_|  | || |  |  (__ \\_|  | |           " << endl;
		cout << "         | |   '.___`-.   | || |    | |   _   | || |  | |    | |  | || |     | |      | || |   '.___`-.   | |           " << endl;
		cout << "         | |  |`\\____) |  | || |   _| |__/ |  | || |  \\  `--'  /  | || |    _| |_     | || |  |`\\____) |  | |           " << endl;
		cout << "         | |  |_______.'  | || |  |________|  | || |   `.____.'   | || |   |_____|    | || |  |_______.'  | |           " << endl;
		cout << "         | |              | || |              | || |              | || |              | || |              | |           " << endl;
		cout << "         | '--------------' || '--------------' || '--------------' || '--------------' || '--------------' |           " << endl;
		cout << "          '----------------'  '----------------'  '----------------'  '----------------'  '----------------'            " << endl;
		cout << "=======================================================================================================================" << endl << endl;

		setTextColour(14);
		cout << "                                                 player chips = $" << playersChips << endl;

		setTextColour(11);
		cout << "Choose a gamemode: " << endl << endl;
		cout << "(1) Play slot machine " << endl;
		cout << "(2) Credits " << endl;
		cout << "(3) Quit Slots " << endl;
		cout << "(4) Player Stats " << endl << endl;
		cout << "Which gamemode would you like to play? (1), (2), (3) or (4): ";

		cin >> mainMenu;

		// Error checking for letters
		if (mainMenu != "1")
		{
			if (mainMenu != "2")
			{
				if (mainMenu != "3")
				{
					if (mainMenu != "4")
					{
						setTextColour(4);
						cout << endl;
						cout << "Invalid input, please choose (1), (2), (3) or (4)" << endl;
						wait(4000);
						mainMenu = "0";
					}
				}
			}
		}

		// While user is playing slots
		while (mainMenu == "1")
		{
			while (playersChips > 0)
			{
				timesPlayed += 1;

				setTextColour(11);
				system("cls");
				cout << endl;
				cout << "You currently have " << playersChips << " chips." << endl << endl;
				cout << "Enter the number of chips you want to bet: ";
				
				cin >> playerAmountBet;

				// If user inputs anything other than an int - show error
				while (cin.fail()) 
				{
					cout << endl;
					setTextColour(4);
					cout << "Error invalid input!" << endl;
					setTextColour(11);
					cout << "Please enter the number of chips you would like to bet: ";
					cin.clear();
					cin.ignore(1000, '\n');
					cin >> playerAmountBet;
				}

				cout << endl;

				// Stops player betting more than they have
				if (playerAmountBet > playersChips)
				{
					setTextColour(4);
					cout << "You do not have enough chips, please bet less chips" << endl;
					wait(3000);
					continue;
				}
				// Ensures players bet at least $1
				else if (playerAmountBet < 1)
				{
					setTextColour(4);
					cout << "You must bet at least 1 chip, please bet more chips" << endl;
					wait(3000);
					continue;
				}
				else
				{
					setTextColour(11);
					amountBet += playerAmountBet;

					playersChips = playersChips - playerAmountBet;

					// call function for slot machine
					newPlayerChips = slotMachine(playersChips, playerAmountBet);

					playersChips = newPlayerChips;

					wait(3000);
					break;
				}
			}

			mainMenu = "0";

			// Prevents overflow
			if (playersChips > 2147483647)
			{
				 playersChips = 2147483647;
			}

			if (playersChips == 0)
			{
				system("cls");
				//wait(500);

				setTextColour(12);

				cout << "You have gambled away all your chips";
				wait(700);
				system("cls");

				cout << "You have gambled away all your chips.";
				wait(700);
				system("cls");

				cout << "You have gambled away all your chips..";
				wait(700);
				system("cls");

				cout << "You have gambled away all your chips...";
				wait(700);
				system("cls");

				while (true)
				{
					string playerRestart = "y";

					system("cls");

					setTextColour(15);

					cout << "Would you like to reset your chips? (Y)es / (N)o: ";

					cin >> playerRestart;


					// checking for upper & lower case
					if (playerRestart == "n" || playerRestart == "N" || playerRestart == "No" || playerRestart == "no")
					{
						system("cls");
						cout << "See you soon";
						wait(700);

						system("cls");
						cout << "See you soon.";
						wait(700);

						system("cls");
						cout << "See you soon..";
						wait(700);

						system("cls");
						cout << "See you soon...";
						wait(700);

						exitGame();
					}
					else if (playerRestart != "Y" && playerRestart != "y" && playerRestart != "Yes" && playerRestart != "yes")
					{
						setTextColour(4);
						cout << "Invalid input, please select (Y)es or (N)o";
						wait(2000);
						continue;
					}
					else
					{
						system("cls");

						setTextColour(12);

						cout << "Just remember ";
						wait(700);
						system("cls");

						cout << "Just remember. ";
						wait(700);
						system("cls");

						cout << "Just remember.. ";
						wait(700);
						system("cls");

						cout << "Just remember... ";
						wait(700);
						system("cls");

						setTextColour(4);

						cout << "You cannot do this in real life";
						wait(3000);

						returnMainMenu();

						timesReset += 1;
						playersChips = 2000;
						break;

					}
				} 
			}
		}

		// While user chooses Credits
		while (mainMenu == "2")
		{
			// Call credits & change the colour (creates multicolourded effect)
			setTextColour(4);
			creditsText();
			wait(500);

			setTextColour(14);
			creditsText();
			wait(500);

			setTextColour(13);
			creditsText();
			wait(500);

			setTextColour(2);
			creditsText();
			wait(500);

			setTextColour(3);
			creditsText();
			wait(500);

			setTextColour(5);
			creditsText();
			wait(500);

			setTextColour(9);
			creditsText();
			wait(500);

			setTextColour(10);
			creditsText();
			wait(500);

			setTextColour(1);
			creditsText();
			wait(500);

			setTextColour(15);
			creditsText();
			wait(500);

			mainMenu = "0";
		}

		// While user chooses to quit slots
		while (mainMenu == "3")
		{
			while (true)
			{
				system("cls");
				// Variable to hold users answer (quit or not)
				string playerQuit = "n";

				// Ask the user if they wish to continue playing slots
				cout << endl;
				cout << "Quit the game? (Y)es or (N)o: ";
				cin >> playerQuit;

				// checking for upper & lower case
				if (playerQuit == "y" || playerQuit == "Y" || playerQuit == "yes" || playerQuit == "Yes")
				{
					exitGame();
				}
				else if (playerQuit != "N" && playerQuit != "n" && playerQuit != "No" && playerQuit != "no")
				{
					cout << "Invalid input, please select (Y)es or (N)o";
					wait(2000);
				}
				else
				{
					returnMainMenu();
					break;

				}
			}
			mainMenu = "0";
		}

		// While user views their stats
		while (mainMenu == "4")
		{
			system("cls");

			cout << endl;

			setTextColour(5);
			cout << "                       @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@" << endl;
			cout << "                               ______ _                         _____ _        _                  " << endl;
			cout << "                               | ___ \\ |                       /  ___| |      | |                " << endl;
			cout << "                               | |_/ / | __ _ _   _  ___ _ __  \\ `--.| |_ __ _| |_ ___           " << endl;
			cout << "                               |  __/| |/ _` | | | |/ _ \\ '__|  `--. \\ __/ _` | __/ __|         " << endl;
			cout << "                               | |   | | (_| | |_| |  __/ |    /\__/ / || (_| | |_\\__ \\         " << endl;
			cout << "                               \\_|   |_|\\__,_|\\__, |\\___|_|    \\____/ \\__\\__,_|\\__|___/   " << endl;
			cout << "                                             __/ |                                                " << endl;
			cout << "                                            |___/                                                 " << endl;
			cout << "                       @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@" << endl << endl;

			setTextColour(4);
			cout << "                        You have played " << timesPlayed << " times." << endl;

			setTextColour(14);
			cout << "                        You have lost all your money " << timesReset << " times." << endl;

			setTextColour(10);
			cout << "                        You have bet $" << amountBet << endl;

			setTextColour(9);
			cout << "                        You have won $" << amountWon << endl;

			setTextColour(13);
			cout << "                        You have lost $" << amountLost << endl;
			wait(10000);
			mainMenu = "0";
		}                        


	}


	return(0);

}

// Function to store the code for the slot machine
int slotMachine(int playersChips, int playerAmountBet)
{
	int chipAmount = playersChips;
	int betAmount = playerAmountBet;
	int newChipAmount = 0;
	int slotsNumber[3];
	int slotIndex = 0;

	for (int i = 0; i < 3; i++)
	{
		slotIndex = i - 1;

		for (int j = 0; j < 10; j++)
		{
			system("cls");

			setTextColour(14);
			cout << "                                                    player chips = $" << playersChips << endl << endl << endl;

			if (i > 0)
			{
				if (i > 1 && i < 3)
				{
					// Draws the first random number again; the screen gets cleared
					drawNumbers(slotsNumber[0]);
				}
				// Draws the second random number again; screen gets cleared
				 drawNumbers(slotsNumber[slotIndex]);
			}

			// Randomises and draws the number 10 times (creates animation)
			slotsNumber[i] = randomNumber();
			drawNumbers(slotsNumber[i]);

			cout << endl;

			wait(200);
		}
	}

	// Calling function to check how many chips they won
	newChipAmount = playerChipWinnings(slotsNumber, chipAmount, betAmount);

	cout << endl;

	wait(5000);

	return newChipAmount;
}

// inline function; one line of code
inline int randomNumber()
{
	int randomNumber = (rand() % 6) + 2;

	return randomNumber;
}

// Function to exit the game
int exitGame()
{
	setTextColour(15);
	system("cls");
	cout << "Exiting slot machine" << endl;
	wait(500);

	system("cls");
	cout << "Exiting slot machine." << endl;
	wait(500);

	system("cls");
	cout << "Exiting slot machine.." << endl;
	wait(500);

	system("cls");
	cout << "Exiting slot machine..." << endl;
	wait(500);

	exit(0);
}

// Function to return to main menu
void returnMainMenu()
{
	setTextColour(15);
	system("cls");
	cout << "Returning to main menu" << endl;
	wait(500);

	system("cls");
	cout << "Returning to main menu." << endl;
	wait(500);

	system("cls");
	cout << "Returning to main menu.." << endl;
	wait(500);

	system("cls");
	cout << "Returning to main menu..." << endl;
	wait(500);
	
}

// Function to make the program wait for x amount of miliseconds 
void wait(int seconds)
{
	clock_t endwait;
	endwait = clock() + seconds * (CLOCKS_PER_SEC / 1000);
	while (clock() < endwait) {}
}

// Function to determine how many chips the player won 
int playerChipWinnings(const int slotIndex[], int chipAmount, int betAmount)
{
	int playerChipAmount = 0;

	// if slots output '777'
	if ((slotIndex[0] == 7) && (slotIndex[1] == 7) && (slotIndex[2] == 7))
	{
		setTextColour(14);
		cout << "JACKPOT!!! You have won 10x your bet" << endl << endl;

		playerChipAmount = chipAmount + (betAmount * 10);

		amountWon += betAmount * 10;

		setTextColour(11);
		cout << "Your chip amount is $" << playerChipAmount;
	}
	// if all numbers are the same
	else if ((slotIndex[0] == slotIndex[1]) && (slotIndex[0] == slotIndex[2]) && (slotIndex[1] == slotIndex[2]))
	{
		setTextColour(9);
		cout << "You have won 5x your bet" << endl << endl;

		playerChipAmount = chipAmount + (betAmount * 5);

		amountWon += betAmount * 5;

		setTextColour(11);
		cout << "Your chip amount is $" << playerChipAmount;
	}
	// if two numbers are the same
	else if ((slotIndex[0] == slotIndex[1]) || (slotIndex[0] == slotIndex[2]) || (slotIndex[1] == slotIndex[2]))
	{
		setTextColour(13);
		cout << "You have won 3x your bet" << endl << endl;

		playerChipAmount = chipAmount + (betAmount * 3);

		amountWon += betAmount * 3;

		setTextColour(11);
		cout << "Your chip amount is $" << playerChipAmount;
	}
	// if they lost
	else
	{
		setTextColour(4);
		cout << "You have lost..." << endl << endl;

		playerChipAmount = chipAmount;

		amountLost += betAmount;

		cout << "Your chip amount is $" << playerChipAmount;
	}
	return playerChipAmount;
}

// Function to define and draw '3D' numbers
void drawNumbers(int slotsNumber)
{
	if (slotsNumber == 2)
	{
		// Uses multidimensional array to define the numbers
		char numTwo[6][10] =
		{
			{ ' ', ' ', '_', '_', '_', '_', '_', ' ', ' ', ' '},
			{ ' ', '/', ' ', '_', '_', '_', ' ', '`', '.', ' '},
			{ '|', '_', '/', '_', '_', '_', ')', ' ', '|', ' '},
			{ ' ', '.', '\'', '_', '_', '_', '_', '.', '\'', ' '},
			{ '/', ' ', '/', '_', '_', '_', '_', '_', ' ', ' '},
			{ '|', '_', '_', '_', '_', '_', '_', '_', '|', ' '}
		};

		setTextColour(15);
		cout << "                                                       --------------   " << endl;

		for (int i = 0; i < 6; ++i)
		{
			cout << "                                                      ";
			cout << "|  ";

			for (int j = 0; j < 10; ++j)
			{
				setTextColour(4);
				cout << numTwo[i][j];
			}

			setTextColour(15);
			cout << "  |" << endl;
		}

		cout << "                                                      |              | " << endl;
		cout << "                                                       --------------  " << endl;
	}
	else if (slotsNumber == 3)
	{
		char numThree[6][10] =
		{
			{ ' ', ' ', '_', '_', '_', '_', '_', '_', ' ', ' '},
			{ ' ', '/', ' ', '_', '_', '_', '_', ' ', '`', '.'},
			{ ' ', '`', '\'', ' ', ' ', '_', '_', ')', ' ', '|'},
			{ ' ', '_', ' ', ' ', '|', '_', '_', ' ', '\'', '.'},
			{ '|', ' ', '\\', '_', '_', '_', '_', ')', ' ', '|'},
			{ ' ', '\\', '_', '_', '_', '_', '_', '_', '.', '\''}
		};

		setTextColour(15);
		cout << "                                                       --------------   " << endl;

		for (int i = 0; i < 6; ++i)
		{
			cout << "                                                      ";
			cout << "|  ";

			for (int j = 0; j < 10; ++j)
			{
				setTextColour(9);
				cout << numThree[i][j];
			}
			
			setTextColour(15);
			cout << "  |" << endl;
		}

		cout << "                                                      |              | " << endl;
		cout << "                                                       --------------  " << endl;
	}
	else if (slotsNumber == 4)
	{
		char numFour[6][10] =
		{
			{ ' ', '_', ' ', ' ', ' ', ' ', '_', ' ', ' ', ' '},
			{ '|', ' ', '|', ' ', ' ', '|', ' ', '|', ' ', ' '},
			{ '|', ' ', '|', '_', '_', '|', ' ', '|', '_', ' '},
			{ '|', '_', '_', '_', '_', ' ', ' ', ' ', '_', '|'},
			{ ' ', ' ', ' ', ' ', '_', '|', ' ', '|', '_', ' '},
			{ ' ', ' ', ' ', '|', '_', '_', '_', '_', '_', '|'}
		};

		setTextColour(15);
		cout << "                                                       --------------   " << endl;

		for (int i = 0; i < 6; ++i)
		{
			cout << "                                                      ";
			cout << "|  ";

			for (int j = 0; j < 10; ++j)
			{
				setTextColour(5);
				cout << numFour[i][j];
			}
			
			setTextColour(15);
			cout << "  |" << endl;
		}

		cout << "                                                      |              | " << endl;
		cout << "                                                       --------------  " << endl;
	}
	else if (slotsNumber == 5)
	{
		char numFive[6][10] =
		{
			{ ' ', '_', '_', '_', '_', '_', '_', '_', ' ', ' '},
			{ '|', ' ', ' ', '_', '_', '_', '_', '_', '|', ' '},
			{ '|', ' ', '|', '_', '_', '_', '_', ' ', ' ', ' '},
			{ '\'', '_', '.', '_', '_', '_', '_', '\'', '\'', '.'},
			{ '|', ' ', '\\', '_', '_', '_', '_', ')', ' ', '|'},
			{ ' ', '\\', '_', '_', '_', '_', '_', '_', '.', '\''}
		};

		setTextColour(15);
		cout << "                                                       --------------   " << endl;

		for (int i = 0; i < 6; ++i)
		{
			cout << "                                                      ";
			cout << "|  ";

			for (int j = 0; j < 10; ++j)
			{
				setTextColour(13);
				cout << numFive[i][j];
			}
			
			setTextColour(15);
			cout << "  |" << endl;
		}

		cout << "                                                      |              | " << endl;
		cout << "                                                       --------------  " << endl;
	}
	else if (slotsNumber == 6)
	{
		char numSix[6][10] =
		{
			{ ' ', ' ', '_', '_', '_', '_', '_', '_', ' ', ' '},
			{ '.', '\'', ' ', '_', '_', '_', '_', ' ', '\\', ' '},
			{ '|', ' ', '|', '_', '_', '_', '_', '\\', '_', '|'},
			{ '|', ' ', '\'', '_', '_', '_', '_', '`', '\'', '.'},
			{ '|', ' ', '(', '_', '_', '_', '_', ')', ' ', '|'},
			{ '\'', '.', '_', '_', '_', '_', '_', '_', '.', '\''}
		};

		setTextColour(15);
		cout << "                                                       --------------   " << endl;

		for (int i = 0; i < 6; ++i)
		{
			cout << "                                                      ";
			cout << "|  ";

			for (int j = 0; j < 10; ++j)
			{
				setTextColour(1);
				cout << numSix[i][j];
			}
			
			setTextColour(15);
			cout << "  |" << endl;
		}

		cout << "                                                      |              | " << endl;
		cout << "                                                       --------------  " << endl;
	}
	else if (slotsNumber == 7)
	{
		char numSeven[6][10] =
		{
			{ ' ', '_', '_', '_', '_', '_', '_', '_', ' ', ' '},
			{ '|', ' ', ' ', '_', '_', '_', ' ', ' ', '|', ' '},
			{ '|', '_', '/', ' ', ' ', '/', ' ', '/', ' ', ' '},
			{ ' ', ' ', ' ', ' ', '/', ' ', '/', ' ', ' ', ' '},
			{ ' ', ' ', ' ', '/', ' ', '/', ' ', ' ', ' ', ' '},
			{ ' ', ' ', '/', '_', '/', ' ', ' ', ' ', ' ', ' '}
		};

		setTextColour(15);
		cout << "                                                       --------------   " << endl;

		for (int i = 0; i < 6; ++i)
		{
			cout << "                                                      ";
			cout << "|  ";

			for (int j = 0; j < 10; ++j)
			{
				setTextColour(10);
				cout << numSeven[i][j];
			}
			
			setTextColour(15);
			cout << "  |" << endl;
		}

		cout << "                                                      |              | " << endl;
		cout << "                                                       --------------  " << endl;
	}
	else
	{
		setTextColour(4);
		cout << "ERROR!";
	}

}

void setTextColour(int colourOfText)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), colourOfText);
}

void creditsText()
{
	system("cls");

	cout << "                       @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@" << endl;
	cout << "                                             _____              _ _ _                                " << endl;
	cout << "                                            /  __ \\            | (_) |                              " << endl;
	cout << "                                            | /  \\/_ __ ___  __| |_| |_ ___                         " << endl;
	cout << "                                            | |   | \'__/ _ \\/ _` | | __/ __|                       " << endl;
	cout << "                                            | \\__/\\ | |  __/ (_| | | |_\\__ \\                     " << endl;
	cout << "                                             \\____/_|  \\___|\\__,_|_|\\__|___/                     " << endl;
	cout << "                                                                                                      " << endl;
	cout << "                       @~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@" << endl << endl;
	 				  	 
	cout << "                                          Slot Machine developed by Toni Natta                 ";


	cout << endl << endl << endl;

	cout << "                                             /^--^\\     /^--^\\     /^--^\\                       " << endl;
	cout << "                                             \\____/     \\____/     \\____/                       " << endl;
	cout << "                                            /      \\   /      \\   /      \\                   " << endl;
	cout << "                                           |        | |        | |        |                     " << endl;
	cout << "                                            \\__  __/   \\__  __/   \\__  __/                   " << endl;
	cout << "                       |^|^|^|^|^|^|^|^|^|^|^|^\\ \\^|^|^|^/ /^|^|^|^|^\\ \\^|^|^|^|^|^|^|^|^|^|^|^|" << endl;
	cout << "                       | | | | | | | | | | | | |\\ \\| | |/ /| | | | | |\\ \\| | | | | | | | | | | |" << endl;
	cout << "                       | | | | | | | | | | | | / / | | |\\ \\| | | | | |/ /| | | | | | | | | | | |" << endl;
	cout << "                       | | | | | | | | | | | | \\/| | | | \\/| | | | | |\\/ | | | | | | | | | | | |" << endl;
	cout << "                       #########################################################################" << endl;
	cout << "                       | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | |" << endl;
	cout << "                       | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | |" << endl;

}
	